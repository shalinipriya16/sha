import tweepy
import json



API_KEY = 'ejsrCyeZodlpzaNQNTzwc2tCT'
API_SECRET = 'yzqeArzOiWpWjBWfy1nXeb5TSWrHnNmfF5iPENcY08xt0OUov7'
ACCESS_TOKEN= '917327613009346561-RREl7Zg0eJi2PoLl4fabl1E6b3EUvjR'
ACCESS_TOKEN_SECRET = 'va65EgDD45zlRb4ADorNa60T6ztG9QriILlIwN5bYaa3P'


key = tweepy.OAuthHandler(API_KEY, API_SECRET)
key.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)




class Stream2Screen(tweepy.StreamListener):
    def on_status(self, status):
        with open('Data/Tweets.json', 'a') as file:
            json.dump(status._json, file)
            file.write('\n')



while True:
	try:
		stream = tweepy.streaming.Stream(key, Stream2Screen())
		stream.sample(languages=['en'])
	except:
		continue

